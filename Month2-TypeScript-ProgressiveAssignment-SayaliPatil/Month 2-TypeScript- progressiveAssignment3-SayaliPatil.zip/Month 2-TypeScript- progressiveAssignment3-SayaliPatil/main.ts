///<reference path = "./Name.ts"/>

let age= Name.AgeCalc(1998);


console.log("Student Profile:  \nName : "+Name.getContent('Sayali')+"\nSurname : "+Name.Surname.getContent('Patil')+"\nAge : "+age );