///<reference path = "./Name.ts"/>
var age = Name.AgeCalc(1998);
console.log("Student Profile:  \n Name : " + Name.getContent('Sayali') + "\nSurname : " + Name.Surname.getContent('Patil') + "\nAge : " + age);
