namespace Name {
    export function getContent (name : string) {
        return name;
    }
    export namespace Surname {
        export function getContent(surname :  string) {
            return surname;
        }
    }
    
        export function AgeCalc(year: number){  
            return 2020-year;  
        }
    
    
    
}


