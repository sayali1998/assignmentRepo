var sum = function (x, y) {
    return x + y;
};
console.log("The sum of two numbers (92 and 73) is: ", sum(92, 73));
