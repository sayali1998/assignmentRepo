"use strict";
exports.__esModule = true;
var node_fetch_1 = require("node-fetch");
function getUser(name) {
    node_fetch_1["default"]("https://api.github.com/users/" + name)
        .then(function (response) {
        return response.json();
    })
        .then(function (json) {
        console.log(json);
    });
}
;
//get user data
getUser('sayali1998');
